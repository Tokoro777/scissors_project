# gym_grasp

## GraspBlock


# Installation

```bash
cd gym-grasp
pip install -e .
```

# How To Use

```python
import gym
import gym_grasp # This includes GraspBlock-v0

env = gym.make('GraspBlock-v0')
```
